"""TRINETRA offline investigation core."""
